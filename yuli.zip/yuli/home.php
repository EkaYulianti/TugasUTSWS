<div>
SELAMAT DATANG 
<br>
Web ini berguna untuk mengetahui prakiraan cuaca diwilayah Semarang dan sekitarnya
</div>